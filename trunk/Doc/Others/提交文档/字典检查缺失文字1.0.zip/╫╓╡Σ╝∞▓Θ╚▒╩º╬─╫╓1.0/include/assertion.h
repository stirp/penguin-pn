//copyrights    :All reserved by Penguin group
//company       :Penguin group
//developer     :lynx
//phone         :15201329144
//function      :assert if it's a char
//version       :0.1
//changlog      :2010\12\10 version0.1

#ifndef ASSERTION_H_INCLUDED
#define ASSERTION_H_INCLUDED

BOOL isEnglish(pychar ch);//判断一个字符是否是英文
BOOL isNumber(pychar ch);//判断一个字符是否是数字
BOOL isSign(pychar ch);//判断一个字符是否是标点符号
BOOL isChinese(pychar ch);//判断一个字符是否是中文
BOOL isOthers(pychar ch);//判断一个字符是否是其他

#endif // ASSERTION_H_INCLUDED
