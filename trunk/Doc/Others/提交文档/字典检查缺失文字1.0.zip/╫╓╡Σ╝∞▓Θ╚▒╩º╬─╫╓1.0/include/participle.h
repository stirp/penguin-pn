#ifndef PARTICIPLE_H_INCLUDED
#define PARTICIPLE_H_INCLUDED

char *matchText(char *inText,int Length);             //将wchar_t型的字符文本切分后，返回相应的拼音。拼音所占内存将在函数中得到分配

#endif // PARTICIPLE_H_INCLUDED
